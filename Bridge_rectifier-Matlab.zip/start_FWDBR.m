clear
close all
clc
A = 12;
f= 50;
N=4;
skew = 0.5;
duty = 50;
Vin= 10;
ok=0;
Tsem=1;

FWDBR(A, f,  N, skew, duty,Vin,ok,Tsem)