#include "Talkthrough.h"
#include <stdbool.h>
#include <cycle_count.h> 
#include <stdio.h> 

//--------------------------------------------------------------------------//
// Function:	Process_Data()												//
//																			//
// Description: This function is called from inside the SPORT0 ISR every 	//
//				time a complete audio frame has been received. The new 		//
//				input samples can be found in the variables iChannel0LeftIn,//
//				iChannel0RightIn, iChannel1LeftIn and iChannel1RightIn 		//
//				respectively. The processed	data should be stored in 		//
//				iChannel0LeftOut, iChannel0RightOut, iChannel1LeftOut,		//
//				iChannel1RightOut, iChannel2LeftOut and	iChannel2RightOut	//
//				respectively.												//
//--------------------------------------------------------------------------//

#define ECHO_BUFFER_SIZE 50000
#define ECHO_DELAY 4500

int volumeFactor = 1; 	// Initial volume factor
int filterState = 0; 	// 0: no filter, 1: echo 

int echoBuffer[ECHO_BUFFER_SIZE];
int echoIndex = 0;

// Function to check state of PF10 button
bool isVolumeButtonPressed(void) {
    return !(*pFIO_FLAG_D & (1 << 10)); // true when PF10 is pressed
}

// Function to check state of PF11 button
bool isEchoButtonPressed(void) {
    return !(*pFIO_FLAG_D & (1 << 11)); // true when PF11 is pressed
}

// Apply 1s echo filter to a signal usiing circular addressing
int echo(int input) {
    int output;
    echoBuffer[echoIndex] = input;
    int delayedIndex = (echoIndex - ECHO_DELAY + ECHO_BUFFER_SIZE) % ECHO_BUFFER_SIZE;
    output = input + (echoBuffer[delayedIndex] >> 2); // 0.25 * delayed signal

    // Update echo index
    echoIndex = (echoIndex + 1) % ECHO_BUFFER_SIZE;
    return output;
}


// Volume control and optional echo effect 
void Process_Data(void) {
	
	// Start counting cycles
	cycle_t start_count;     
	cycle_t final_count;     
	START_CYCLE_COUNT(start_count); 
	
    // Check if volume button is pressed
    static bool lastVolumeButtonState = false;
    bool volumeButtonState = isVolumeButtonPressed();
    if (volumeButtonState && !lastVolumeButtonState) {
        volumeFactor = (volumeFactor + 1) % 5; // Increase volume factor up to 4 then reset
    }
    lastVolumeButtonState = volumeButtonState;

    // Check if filter button is pressed
    static bool lastEchoButtonState = false;
    bool echoButtonState = isEchoButtonPressed();
    if (echoButtonState && !lastEchoButtonState) {
        filterState = (filterState + 1) % 2; // Cycle through filter states: 0, 1
    }
    lastEchoButtonState = echoButtonState;

	// Apply selected filter and volume
    switch (filterState) {
        case 1: // Echo and volume
            iChannel0LeftOut = echo(iChannel0LeftIn) * volumeFactor;
            iChannel0RightOut = echo(iChannel0RightIn) * volumeFactor;
            break;
        default: // Just volume
        	iChannel0LeftOut = iChannel0LeftIn * volumeFactor;
            iChannel0RightOut = iChannel0RightIn * volumeFactor;
            break;
    }

	// leave channel 1 as is for testing
	iChannel1LeftOut = iChannel0LeftIn;
	iChannel1RightOut = iChannel0RightIn;
	
	// Stop counting cycles and determine if real-time is achieved
	STOP_CYCLE_COUNT(final_count,start_count); 
	PRINT_CYCLES("Number of cycles: ",final_count); 	
	
}

